20191621 이민영
SIC/XE머신 구현을 위해서 shell과 실행될 메모리 공간과 mnemonic을 opcode로 변환시켜주는 opcodetable을 구현하였다. 

실행 환경 : 리눅스
실행 방법 : make를 입력해서 컴파일 한 후, ./20191621.out을 입력해서 실행한다.