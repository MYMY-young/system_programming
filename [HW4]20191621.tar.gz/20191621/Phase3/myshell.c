#include "myshell.h"
#include <errno.h>
#define MAXARGS 128

int pid_add[100];
char pid_name[100][100];
int pid_num=1;
int argc=0;
int pid_flag[100] = {0, };
typedef void handler_t(int);

void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv);
void Close(int fd);
int Dup2(int fd1, int fd2);
void Execve(const char *filename, char *const argv[], char *const envp[]);
pid_t Wait(int *status);
pid_t Waitpid(pid_t pid, int *iptr, int options);
handler_t *Signal(int signum, handler_t *handler);
void Kill(pid_t pid, int signum);
void childHandler();
void Sigaddset(sigset_t *set, int signum);
void Sigdelset(sigset_t *set, int signum);
int Sigismember(const sigset_t *set, int signum);
int Sigsuspend(const sigset_t *set);
sigset_t set[100];

int main(){
    	char cmdline[MAXLINE];
	while(1){
		//Shell Prompt : print your set_ *set, int signprompt	
	
	    printf("CSE4100-SP-P#4> ");

		//Reading : Read the command from standard input
		char* result = fgets(cmdline, MAXLINE, stdin);
		

		eval(cmdline);
		cmdline[0]='\0';
	
		if(feof(stdin))
		    exit(0);
	
	}

}

void eval(char* cmdline){
	char *argv[MAXARGS];
	char buf[MAXLINE];
//	char temp[MAXLINE];
	int bg;
	pid_t pid;
	
	int flag_pipe[MAXARGS];
	int num;
	int status;

	

	strcpy(buf, cmdline);			//입력받은 cmdline 을 buf에 복사한다.
	bg = parseline(buf, argv);		//parseline을 
	if(argv[0] == NULL)
	    return;
	if(!builtin_command(argv)){
		if(bg){
			printf("[%d] %d\n", pid_num,getpid());
			pid_add[pid_num] = getpid();
			strcpy(pid_name[pid_num] , argv[0]);
			pid_num++;
			signal(SIGINT, SIG_IGN);
			signal(SIGTSTP,SIG_IGN);
		}
		else{
			signal(SIGINT, SIG_DFL);
			signal(SIGINT, SIG_DFL);
		}

	    	
	    	num = 0;
	    	for(int i=0;i<argc;i++){
			if(strcmp(argv[i],"|")==0){
			    argv[i] = NULL;
			    flag_pipe[num++]=i;
			}
		}		
		if(num>0){
		   //pipe가 존재할 때 
	 		int status1;
			//pid 생성됨.
			pid = Fork();
			pid_add[0] = 0;
			

			if(pid<0){
			  	exit(1);
			
			}
			else if(pid == 0){
				//자식일 때
			     
				int fp[60][2] = {0,};
				int aaa = pipe(fp[0]);
			   
				pid_t pid2;
				pid2 = fork();
			    
				if((pid2 )<0){
				
					exit(1);
				}
				else if(pid2==0){
				
			    		Close(STDOUT_FILENO);
					Dup2(fp[0][1], STDOUT_FILENO);
					Close(fp[0][1]);
						
				
					execvp(argv[0],&argv[0]);
				}
			    
 				Close(fp[0][1]);
				Wait(&status);
			 
			    
		    
				for(int j=0;j<num-1;j++){
			
					
					if(pipe(fp[j+1])<0) exit(-1);
					
					if((pid2=Fork())<0)exit(-1);
					else if(pid2==0){
						Close(STDIN_FILENO);
						Close(STDOUT_FILENO);
						Dup2(fp[j][0],STDIN_FILENO);
						Dup2(fp[j+1][1],STDOUT_FILENO);
						Close(fp[j][0]);
						Close(fp[j+1][1]);
						execvp(argv[flag_pipe[num-1]+1],&argv[flag_pipe[num-1]+1]);
			
					}
					Close(fp[j+1][1]);
					Wait(&status);
					if(WIFSIGNALED(status1) || WIFSTOPPED(status1))
						exit(1);
				}
			   

				
				pid2 = Fork();
			
				if((pid2)<0){
					exit(1);
				}
				else if(pid2==0){
					Close(STDIN_FILENO);
					Dup2(fp[num-1][0], STDIN_FILENO);
					Close(fp[num-1][0]);
		
					execvp(argv[flag_pipe[num-1]+1],&argv[flag_pipe[num-1]+1]);
					
				}
			
				Wait(&status);
				if(WIFSIGNALED(status1) || WIFSTOPPED(status1))
					exit(1);

				exit(0);
			}
			else if(pid>0){
				
			    int status_p;
			    if(!bg){
		    		
			
				waitpid(pid, &status_p, 0);
		
			    }
			    else{
			   //background
				if(WIFEXITED(status_p) != 0)
				    pid_flag[pid_num-1] = 1;
					//자식 프로세스가 올바르게 끝났을 경우에는 jobs에서 없앤다.
			    	
			    }
			}
	
		}
		else{
		   
			pid_t pid3;
			if(strcmp(argv[0],"fg")==0){
			    	//fg를 입력했을 경우에, 멈춰있거나 실행되고있는 백그라운그 job을 foreground에서 실행한다.
				int fg_num;
				sscanf(&argv[1][1],"%d",&fg_num);
				signal(SIGCONT,SIG_DFL);
				Kill(pid_add[fg_num],SIGCONT);
				exit(1);
	
			}
		    	if(strcmp(argv[0],"cd")==0){
			    	if(argv[1] == NULL){
					int a =	chdir(getenv("HOME"));
				}
				else{
					int b = chdir(argv[1]);
				}
			}
			else if(strcmp(argv[0],"jobs")==0){
			    //jobs가 입력되었을 때 job 출력하기
				for(int i=1;i<pid_num;i++){
				        if(pid_flag[i] != 1){
					printf("[%d] %d %s\n",i,pid_add[i],pid_name[i]);
					}
				}
			}
			else if(strcmp(argv[0],"kill")==0){
			    //kill이 입력되면 해당하는 jobs를 kill시키고 jobs 목록에서도 없앤다.
			        int a;
				
				sscanf(&argv[1][1], "%d",&a);

				Kill(pid_add[a],SIGKILL);
				pid_add[a] = -1;

				pid_flag[a]=1;
			
			}
			else if(strcmp(argv[0],"bg")==0){
			    	//bg가 입력된 경우에 멈춰져 있는 jobs를 background에서 다시 수행시킨다.
				int b;
				sscanf(&argv[1][1],"%d",&b);
				signal(SIGCONT,SIG_DFL);

			}
	
			else{
	    	//	strcpy(temp,"/bin/");
	//			strcat(temp,argv[0]);
			pid3 = Fork();
			//Fork()
			if(pid3 == 0){

				pid_flag[pid_num-1]=1;
			}
			if(!bg){
				//foreground일 경우에 defualt 값을 실행한다.
				signal(SIGINT, SIG_DFL);
				signal(SIGTSTP, SIG_DFL);
			}

			else{
			    	//background일 경우에 무시한다.
				signal(SIGINT, SIG_IGN);
				signal(SIGTSTP, SIG_IGN);
			}
			if((pid3) ==0){
			  	//자식일 경우에
			     
			    pid_flag[pid_num-1]=1;
			    Sigaddset(set,SIGCHLD);
			    execvp(argv[0],&argv[0]);
		//	    if(execve(temp, argv,environ) < 0){
	//				printf("%s: Command not found. \n", argv[0]);
//					exit(0);
//				}

			}
				int status2;
				if(!bg){
					//foreground
					if(waitpid(pid3, &status2, 0) <0 ){
					    unix_error("waitfg: waitpid error");
					}
				}
				else
				{	
					if(Sigismember(set,SIGCHLD)==1)
					    pid_flag[pid_num-1] = 1;
					if(WIFEXITED(status2) != 0)
					    pid_flag[pid_num-1]=1;
		
					//자식이 성공적으로 마쳤을 경우에는 jobs에서 없애기		
				}



		        }
	}
	         
		
	return;
     }
}

void unix_error(char *msg){
	printf("%s: %s\n", msg, strerror(errno));
	exit(0);
}

pid_t Fork(void){
	pid_t pid;
	if((pid = fork()) < 0){
		unix_error("Fork error");
	}
  

	return pid;
}



int builtin_command(char **argv){
	if (!strcmp(argv[0], "quit"))
	    exit(0);
	if(!strcmp(argv[0],"exit"))
	    exit(0);
	if(!strcmp(argv[0], "&"))
	    return 1;
	return 0;
	
}

int parseline(char *buf, char **argv){

	char *delim;
	int bg;
	char temp[MAXLINE];
	
	buf[strlen(buf)-1] = ' ';
	while(*buf && (*buf == ' '))
	    buf++;
	argc=0;
	int c=0;
	int k=0;
	

	c = strlen(buf);

	for(int i=0;i<c;i++){
	    
		if(buf[i+1] == '|'){
		
			
			temp[k++] = buf[i];
			temp[k++] = ' ';
			temp[k++] = '|';
			temp[k++] = ' ';
			i++;
			
		}
		else{
			temp[k] = buf[i];
			k++;

		}

	}
	temp[k+1] = '\0';

	buf = temp;
	while((delim = strchr(buf, ' '))){
		argv[argc++] = buf;
		*delim = '\0';
		buf = delim + 1;
		while(*buf && (*buf == ' '))
			buf++;
	}
	argv[argc] = NULL;

	if(argc == 0){
		return 1;
	}

	if((bg = (*argv[argc-1] == '&')) != 0){
		argv[--argc] = NULL;
	}

	return bg;
}

int Dup2(int fd1, int fd2){
	
    int rc;
    
    if((rc=dup2(fd1, fd2))<0)
	unix_error("Dup2 error");
    return rc;


}

void Execve(const char *filename, char *const argv[], char *const envp[]){

    if (execve(filename, argv, envp) < 0)
	unix_error("Execve error");

}


pid_t Wait(int *status){

    pid_t pid;

    if((pid = wait(status)) < 0)
	unix_error("Wait error");

    return pid;

}

pid_t Waitpid(pid_t pid, int *iptr, int options){

    pid_t retpid;

    if((retpid = waitpid(pid, iptr, options)) < 0)
	unix_error("Waitpid error");

    return(retpid);

}

void Close(int fd){

    int rc;

    if ((rc = close(fd)) < 0)
	unix_error("Close error");
}

void Kill(pid_t pid, int signum){
	int rc;
	if((rc = kill(pid, signum))<0)
	    unix_error("Kill error");

}

handler_t *Signal(int signum, handler_t *handler){
    	printf("aa");
	struct sigaction action, old_action;
	action.sa_handler = handler;
	sigemptyset(&action.sa_mask);
	action.sa_flags = SA_RESTART;
	printf("CCCCC");

	if(sigaction(signum, &action, &old_action) < 0)
	    unix_error("Signal error");
	return (old_action.sa_handler);

}

void Sigaddset(sigset_t *set, int signum){
	
    if(sigaddset(set,signum)<0)
	unix_error("Sigaddset error");
    return;

}

void Sigdelset(sigset_t *set, int signum){

	if (sigdelset(set,signum)<0)
	    unix_error("Sigdelset error");
	return;
}

int Sigismember(const sigset_t * set, int signum){
	int rc;
	if((rc = sigismember(set, signum))<0)
	    unix_error("Sigismember error");
	return rc;

}

int Sigsuspend(const sigset_t *set){
	int rc = sigsuspend(set);
	if(errno != EINTR){
		unix_error("Sigsuspend error");

	}
	return rc;


}
