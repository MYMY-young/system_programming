#include "myshell.h"
#include <errno.h>
#define MAXARGS 128

void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv);

void Close(int fd);
int Dup2(int fd1, int fd2);
pid_t Wait(int *status);
pid_t Waitpid(pid_t pid, int *iptr, int options);


int argc=0;
int main(){
    	char cmdline[MAXLINE];
	while(1){
		//Shell Prompt : print your prompt	
	
	    	printf("CSE4100-SP-P#4> ");

		//Reading : Read the command from standard input
		char* result = fgets(cmdline, MAXLINE, stdin);
		//eval 함수 실행
       	    eval(cmdline);

		cmdline[0]='\0';// cmdline의 끝을 '\0'으로 설정
	
		if(feof(stdin))
		    exit(0);
	
	}

}

void eval(char* cmdline){
	char *argv[MAXARGS];
	char buf[MAXLINE];
	char temp[MAXLINE];
	int bg;
	pid_t pid;
	
	int flag_pipe[MAXARGS];
	int num;
	int status;
	

	strcpy(buf, cmdline);			//buf에 cmdline 복사
	bg = parseline(buf, argv);		//parseline함수를 통해서 명령어 분리

	if(argv[0] == NULL)			//아무것도 들어오지 않았다면 종료
	    return;
	if(!builtin_command(argv)){		//정해진 cmd일 때
	    	num = 0;
	
	    	for(int i=0;i<argc;i++){
			if(strcmp(argv[i],"|")==0){
			    argv[i] = NULL;
			    flag_pipe[num++]=i;
			    //파이프가 존재할 경우 그 위치를 파악하기 위해서 flag_pipe 배열에 위치 저장

			}
		}
			
		if(num>0){
		   	//파이프가 존재할 경우에
			int k=0;
		    
		   
		     
		    //pid 생성됨.
		    pid = fork();
		    //fork실행
		    if(pid<0){
			//에러 존재
		    	exit(1);
			
		    }
		    else if(pid == 0){
			//자식프로세스인 경우에
			    int fp[60][2] = {0,};//파이프 변수 선언
			    k = pipe(fp[0]);
			    //파이프 생성한다.
			    pid_t pid2;
			    pid2 = Fork();
			    //fork()한다.
			    
			    if((pid2 )<0){
				//에러가 나면 종료한다.
				exit(1);
			    }
			    else if(pid2==0){
				//자식 프로세스인 경우에
				
			    	Close(STDOUT_FILENO);
				Dup2(fp[0][1], STDOUT_FILENO);
				Close(fp[0][1]);
				//복사를 하고, 자식의 경우에 output이 없으므로 close한다.
			
				execvp(argv[0],&argv[0]);
				//실행한다.
			    }
			    
			    Close(fp[0][1]);
			    //close한다.
			 
			    Wait(&status);
			    
			   for(int j=0;j<num-1;j++)	{
				   
		
				
						
					
				
					if(pipe(fp[j+1])<0) exit(-1);
					//올바르지 않을 경우에 exit
					if((pid2=Fork())<0)exit(-1);//fork 에러나면 종료한다.

					else if(pid2==0){	//자식 프롯스의 경우에
					    
					    Close(STDIN_FILENO);
					    Close(STDOUT_FILENO);
					    Dup2(fp[j][0],STDIN_FILENO);
					    Dup2(fp[j+1][1],STDOUT_FILENO);
					    Close(fp[j][0]);
					    Close(fp[j+1][1]);
					    //복사를 하고 쓰지 않는 파이프를 닫는다.
					   
					    execvp(argv[flag_pipe[num-1]+1],&argv[flag_pipe[num-1]+1]);
					    //함수를 통해서 명령어를 실행한다.
					    
					}
					Close(fp[j+1][1]);
					Wait(&status);//부모가 사직을 기다린다.
				
			    }
			   
			    	
			    	
				
				pid2 = Fork();			//Frok실행한다.
				if((pid2)<0){			//오류가 발생하면 종료한다.
					exit(1);
				}
				else if(pid2==0){		//자식 프로세스의 경우에
					Close(STDIN_FILENO);
					Dup2(fp[num-1][0], STDIN_FILENO);
					Close(fp[num-1][0]);
					
						//사용하지 않는 파이프를 닫고 명령어를 수행한다.
					execvp(argv[flag_pipe[num-1]+1],&argv[flag_pipe[num-1]+1]);

				}

				Wait(&status);
				//자식을 기다린다.
				if(WIFSIGNALED(status) || WIFSTOPPED(status))
				    exit(1);

				exit(0);
			    }
		     else{
			 if(!bg){
			//foreground 일 경우에 부모 프로세스가 자식 프로세스를 기다린다.
		    	int status_p;
			
			Waitpid(pid, &status_p, 0);
			
			 }
			
		    }
		   	
		
		}
		else{	//Phase1과 동일하다.
			pid_t pid3;
		    	if(strcmp(argv[0],"cd")==0){ //cd일 경우 실행
			    	if(argv[1] == NULL){
					int a = chdir(getenv("HOME"));
				}
				else{
					int b = chdir(argv[1]);
				}
			}
			else{
	
	    		strcpy(temp,"/bin/");
			strcat(temp,argv[0]);
			
			if((pid3 = Fork()) ==0){
			    
				//자식 프로세스의 경우에 execve 실행하기
			    	if(execve(temp, argv,environ) < 0){
					printf("%s: Command not found. \n", argv[0]);
					exit(0);
				}
			}

			if(!bg){ //foreground일 경우에 부모가 자식을 기다린다.
				int status;
			if(waitpid(pid3, &status, 0) <0 ) //에러가 나면 메시지 출력한다.
			    unix_error("waitfg: waitpid error");
			}
			else{
			    printf("%d %s", pid3, cmdline);
			}
		
		}
		}
		
	return;
     }
}

void unix_error(char *msg){
	printf("%s: %s\n", msg, strerror(errno));
	exit(0);
}

pid_t Fork(void){
	pid_t pid;
	if((pid = fork()) < 0){
		unix_error("Fork error");
	}

	return pid;
}



int builtin_command(char **argv){
	if (!strcmp(argv[0], "quit"))
	    exit(0);
	if(!strcmp(argv[0],"exit"))
	    exit(0);
	if(!strcmp(argv[0], "&"))
	    return 1;
	return 0;
	
}

int parseline(char *buf, char **argv){

	char *delim;
	int bg;
	char temp[MAXLINE];
	buf[strlen(buf)-1] = ' ';
	while(*buf && (*buf == ' '))
	    buf++;
	argc=0;
	int k=0;
	int c = strlen(buf);

	for (int i=0;i<c;i++){
		if(buf[i+1] == '|'){
			temp[k++] =buf[i];
			temp[k++] = ' ';
			temp[k++] = '|';
			temp[k++] = ' ';
			i++;
		}
		else {
			temp[k] = buf[i];
			k++;
		}


	} 
	//띄어쓰기가 |를 사이로 존재하지 않을경우 처리한다.
	temp[k+1] = '\0';
	buf = temp;
	while((delim = strchr(buf, ' '))){
		argv[argc++] = buf;
		*delim = '\0';
		buf = delim + 1;
		while(*buf && (*buf == ' '))
			buf++;
	}
	argv[argc] = NULL;

	if(argc == 0){
		return 1;
	}

	if((bg = (*argv[argc-1] == '&')) != 0){
		argv[--argc] = NULL;
	}

	return bg;
}

pid_t Wait(int *status) 
{
    pid_t pid;

    if ((pid  = wait(status)) < 0)
	unix_error("Wait error");
    return pid;
}
/* $end wait */

pid_t Waitpid(pid_t pid, int *iptr, int options) 
{
    pid_t retpid;

    if ((retpid  = waitpid(pid, iptr, options)) < 0) 
	unix_error("Waitpid error");
    return(retpid);
}

void Close(int fd)
{
    int rc;

    if ((rc = close(fd)) < 0)
	unix_error("Close error");
}

int Dup2(int fd1, int fd2)
{
    int rc;

    if ((rc = dup2(fd1, fd2)) < 0)
	unix_error("Dup2 error");
    return rc;
}

