#include "myshell.h"
#include <errno.h>
#define MAXARGS 128

void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv);


int main(){
    	char cmdline[MAXLINE];
	while(1){
		//Shell Prompt : print your prompt	
	
	    	printf("CSE4100-SP-P#4> ");

		//Reading : Read the command from standard input
		char *result = fgets(cmdline, MAXLINE, stdin);

		eval(cmdline); //eval 함수 실행
		cmdline[0]='\0'; //cmdline의 끝을 '\0'로 설정
	
		if(feof(stdin))
		    exit(0);
	
	}

}

void eval(char* cmdline){
	char *argv[MAXARGS];
	char buf[MAXLINE];
	char temp[MAXLINE];
	int bg;
	pid_t pid;

	strcpy(buf, cmdline);			//buf에 cmdline 복사
	bg = parseline(buf, argv);		//parseline 함수를 통해서 명령어 분리하기

	if(argv[0] == NULL)			//아무것도 들어오지 않았을 때 종료
	    return;
	if(!builtin_command(argv)){		//정해진 command일 때 

	    	if(strcmp(argv[0],"cd")==0){		//cd일 경우에 디렉토리
		    	if(argv[1] == NULL){
				int a = chdir(getenv("HOME"));
			}
			else{
				int b = chdir(argv[1]);
			}
		}
		else{
	
	    	strcpy(temp,"/bin/");				//경로를 위해서 /bin/ 넣어주기
		strcat(temp,argv[0]);				//argv에 붙이기
		//strcpy(argv[0],temp);
		if((pid = Fork()) ==0){
	
		    		//자식 프로세스일 경우에
		    	if(execve(temp, argv,environ) < 0){
			    	//명령어 실행하기, 올바르지 않을 경우에 에러 메시지 출력한다.
				printf("%s: Command not found. \n", argv[0]);
				exit(0);
			}
		}

		if(!bg){			//foreground일 때 부모가 자식 프로세스를 기다린다.
			int status;
			if(waitpid(pid, &status, 0) <0 )
			    unix_error("waitfg: waitpid error");
		}
		else{
		    //background인 경우
		    printf("%d %s", pid, cmdline);
		}
		}
	return;
	}
}

void unix_error(char *msg){
    //에러 있을 때 에러메시지를 출력한다.
	printf("%s: %s\n", msg, strerror(errno));
	exit(0);
}

pid_t Fork(void){
    	//fork를 수행하고 에러가 있을 경우에 에러를 출력한다.
	pid_t pid;
	if((pid = fork()) < 0){
		unix_error("Fork error");
	}
    

	return pid;
}



int builtin_command(char **argv){

    	//quit, exit가 들어올 경우에 종료한다.
	if (!strcmp(argv[0], "quit"))
	    exit(0);
	if(!strcmp(argv[0],"exit"))
	    exit(0);
	if(!strcmp(argv[0], "&"))
	    return 1;
	return 0;
	
}

int parseline(char *buf, char **argv){

	char *delim;
	int argc;
	int bg;

	buf[strlen(buf)-1] = ' ';
	while(*buf && (*buf == ' '))
	    buf++;
	argc=0;
	while((delim = strchr(buf, ' '))){
	    	//띄어쓰기가 나오면 띄어쓰기를 기준으로 값을 분리한다.
		argv[argc++] = buf;
		*delim = '\0';
		buf = delim + 1;
		while(*buf && (*buf == ' '))
			buf++;
	}
	argv[argc] = NULL;

	if(argc == 0){
		return 1;
	}

	if((bg = (*argv[argc-1] == '&')) != 0){
		argv[--argc] = NULL;	//띄어쓰기가 있을 경우에 이를 무시한다.
	}

	return bg;
}
