/* 
 * echoserveri.c - An iterative echo server 
 */ 
/* $begin echoserverimain */
#include <time.h>
#include "csapp.h"
#define SBUFSIZE 16
typedef struct{
	int *buf;
	int n;
	int front;
	int rear;
	sem_t mutex;
	sem_t slots;
	sem_t items;

}sbuf_t;

sbuf_t sbuf;
void echo(int connfd);
void *thread(void *vargp);
void sbuf_init(sbuf_t *sp, int n);
void sbuf_deinit(sbuf_t *sp);
void sbuf_insert(sbuf_t *sp, int item);;
int sbuf_remove(sbuf_t *sp);
FILE *ff;

int num=0;
typedef struct item{
	int ID;
	int left_stock;
	int price;
	int readcnt;
	int num;
	struct item *left, *right;
	sem_t mutex;
}item;


void sbuf_init(sbuf_t *sp, int n){
	sp->buf = Calloc(n,sizeof(int));
	sp->n = n;
	sp->front = sp->rear = 0;
	Sem_init(&sp->mutex,0,1);
	Sem_init(&sp->slots,0,n);
	Sem_init(&sp->items,0,0);
}

void sbuf_deinit(sbuf_t *sp){
	Free(sp->buf);
}

void sbuf_insert(sbuf_t *sp, int item){
	P(&sp->slots);
	P(&sp->mutex);
	sp->buf[(++sp->rear)%(sp->n)] = item;
	V(&sp->mutex);
	V(&sp->items);

}

int sbuf_remove(sbuf_t *sp){
	int item;
	P(&sp->items);
	P(&sp->mutex);
	item = sp->buf[(++sp->front)%(sp->n)];
	V(&sp->mutex);
	V(&sp->slots);
	return item;

}

item* search(item* node, int ID){
	if(node == NULL)return NULL;
	if(ID == node->ID)return node;
	else if(ID < node->ID)
	    return search(node->left, ID);
	else
	    return search(node->right, ID);
}

item* new_node(int ID, int left_stock, int price){
	item* temp = (item*)malloc(sizeof(item));
	temp->ID = ID;
	temp->left_stock = left_stock;
	temp->price = price;
	temp->left = temp->right = NULL;
	return temp;
}
item* insert_node(item* node, int ID, int left_stock, int price){
	num++;
	if(node==NULL)return new_node(ID, left_stock, price);
	if(ID < node->ID)
	    node->left = insert_node(node->left, ID, left_stock, price);
	else if(ID > node->ID)
	    node->right = insert_node(node->right, ID, left_stock, price);

	return node;
}
char aa[MAXLINE];
int a_num=0;
void printTree(item* Tree){
	if(Tree == NULL) return;
	printTree(Tree->left);
	if(a_num==0){
		sprintf(aa, "%d %d %d",Tree->ID, Tree->left_stock, Tree->price);
		a_num=1;
	}
	else{
		sprintf(aa,"%s %d %d %d",aa,Tree->ID, Tree->left_stock,Tree->price);
	}
//	printf("%d %d %d\n", Tree->ID, Tree->left_stock, Tree->price);
//	fprintf(ff, "%d %d %d\n", Tree->ID, Tree->left_stock, Tree->price);
	printTree(Tree->right);
}
void printTofile(item* Tree, FILE *fp2){
	if(Tree == NULL)return;
	printTofile(Tree->left,fp2);
	fprintf(fp2, "%d %d %d\n",Tree->ID, Tree->left_stock, Tree->price);
	printTofile(Tree->right,fp2);

}

char buffer[MAXLINE];
item *st_item;
int cli_num=0;
clock_t start1, end1;
int main(int argc, char **argv) 

{
  //  clock_t start1, start2, end1, end2;
    
    int listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;  /* Enough space for any address */  //line:netp:echoserveri:sockaddrstorage
    //char client_hostname[MAXLINE], client_port[MAXLINE];
    pthread_t tid;
    int a, b, c;
    char line[MAXLINE];
    st_item = NULL;
    FILE* fp = fopen("stock.txt","r");
    ff = fopen("temp.txt","w");
    while(!feof(fp)){
	if(fgets(line,MAXLINE,fp)!=NULL){
	sscanf(line,"%d %d %d",&a,&b,&c);
	st_item = insert_node(st_item, a, b, c);
	}
    }

    if (argc != 2) {
	fprintf(stderr, "usage: %s <port>\n", argv[0]);
	exit(0);
    }

    listenfd = Open_listenfd(argv[1]);
    //++
    long NTHREADS = atoi(argv[1]);
    sbuf_init(&sbuf, SBUFSIZE);
    for(int i=0;i<NTHREADS;i++)
	Pthread_create(&tid, NULL, thread,NULL);
    start1 = clock();
    while (1) {
	clientlen = sizeof(struct sockaddr_storage); 
	//connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
        //Getnameinfo((SA *) &clientaddr, clientlen, client_hostname, MAXLINE, 
               //     client_port, MAXLINE, 0);
//	connfdp = Malloc(sizeof(int));
	connfd = Accept(listenfd, (SA *) &clientaddr, &clientlen);
	cli_num++;
//	printf("\nnumnum : %d\n",cli_num);
	sbuf_insert(&sbuf, connfd);
//	Pthread_create(&tid, NULL, thread, connfdp);
//        printf("Connected to (%s, %s)\n", client_hostname, client_port);
//	echo(connfd);
//	Close(connfd);
    }
  //  end1 = clock();
   // printf("time : %f\n",(float)(end1-start1)/CLOCKS_PER_SEC);
    exit(0);
}

static int byte_cnt;
static sem_t mutex;
static void init_echo_cnt(void){
	Sem_init(&mutex, 0, 1);
	byte_cnt = 0;
}


void *thread(void *vargp){
//	int connfd = *((int*)vargp);
	Pthread_detach(pthread_self());
//	Free(vargp);
	char buf[MAXLINE];
	int show_flag=0;
	int buy_flag=0;
	int sell_flag=0;
	int exit_flag=0;
	int buy_ID=0;
	int buy_num=0;
	int sell_ID=0;
	int sell_num=0;
	char show[4] = "show";
	char buy[3] = "buy";
	char sell[4] = "sell";
	char exit[4] = "exit";
	int n;

	int connfd = sbuf_remove(&sbuf);
	rio_t rio;
	static pthread_once_t once = PTHREAD_ONCE_INIT;
	Pthread_once(&once, init_echo_cnt);
	Rio_readinitb(&rio, connfd);
	while((n=Rio_readlineb(&rio, buf, MAXLINE)) != 0){
	    	P(&mutex);
		byte_cnt += n;
		show_flag=0;
		buy_flag=0;
		sell_flag=0;

		for(int i=0;i<4;i++){
			if(buf[i] == show[i])
			    show_flag++;
			if(buf[i] == sell[i])
			    sell_flag++;
			if(buf[i] == exit[i])
			    exit_flag++;
		}
		for(int i=0;i<3;i++){
			if(buf[i] == buy[i])
			    buy_flag++;
		}
		if(show_flag == 4){
			printTree(st_item);
			sprintf(buffer,"%s\n",aa);
			a_num=0;
		//	fread(buffer, 1, MAXLINE, ff);
		//	printf("%s", buffer);
		}
		if(buy_flag == 3){
		//	buy_ID = (int)buf[4] - 48;
		//	buy_num = (int)buf[6] - 48;
		    	sscanf(buf, "buy %d %d",&buy_ID, &buy_num);
			item* temp = search(st_item, buy_ID);
			if(temp == NULL){
				sprintf(buffer,"Not left stock\n");
			}
			else if(temp->left_stock >= buy_num){
				temp->left_stock = temp->left_stock - buy_num;
				sprintf(buffer,"[buy] success\n");
			}
			else{
				sprintf(buffer,"Not left stock\n");
			}
		}
		if(sell_flag == 4){
		//	sell_ID = (int)buf[5] - 48;
		//	sell_num = (int)buf[7] - 48;
		    	sscanf(buf,"sell %d %d",&sell_ID, &sell_num);
			item* temp2 = search(st_item, sell_ID);
			if(temp2 == NULL){
				//printf("no data\n");
			}
			else{
				temp2->left_stock = temp2->left_stock + sell_num;
				sprintf(buffer,"[sell] success\n");
			}
		}
		if(exit_flag == 4){
			break;	
		}
		V(&mutex);
		Rio_writen(connfd, buffer, strlen(buffer));
	}
	cli_num--;
//	printf("cli num : %d\n",cli_num);
	if(cli_num==0){
	    	end1 = clock();
		printf("time : %f\n",(float)(end1-start1)/CLOCKS_PER_SEC);
//	    	printf("end!!!!!!!!!!!!!!!!!!!!!\n");
		FILE *fp2 = fopen("stock.txt","w");
		printTofile(st_item,fp2);
		fclose(fp2);
	}
//	end1 = clock();
//	printf("!!!!!");
	Close(connfd);
	return NULL;
}

/* $end echoserverimain */
