/* 
 * echoserveri.c - An iterative echo server 
 */ 
/* $begin echoserverimain */
#include "csapp.h"
#include <stdlib.h>
#include <time.h>
void echo(int connfd);
void command(void);
//Item* serach(item* node, int ID);
//Item* insert_node(item* node, int ID);
int num=0;
FILE *ff;
char *string=NULL;
clock_t start1, end1;
int cli_num=0;

typedef struct item{
	int ID;
	int left_stock;
	int price;
	int readcnt;
	int num;
	struct item *left, *right;
	sem_t mutex;

}item;
item* st_item;
typedef struct{
	int maxfd;
	fd_set read_set;
	fd_set ready_set;
	int nready;
	int maxi;
	int clientfd[FD_SETSIZE];
	rio_t clientrio[FD_SETSIZE];
}pool;
int byte_cnt=0;

item* search(item* node, int ID){
	if (node == NULL)return NULL;
	if(ID == node->ID) return node;
	else if(ID < node->ID)
	    return search(node->left, ID);

	else
	    return search(node->right, ID);
}
item* new_node(int ID, int left_stock, int price){
	item* temp = (item*)malloc(sizeof(item));
	temp->ID = ID;
	temp->left_stock = left_stock;
	temp->price = price;
	temp->left = temp->right = NULL;
	return temp;

}
item* insert_node(item* node, int ID, int left_stock, int price){

	num++;
	if(node == NULL)return new_node(ID,left_stock, price);

	if(ID < node->ID)
	    node->left = insert_node(node->left, ID,left_stock, price);
	else if(ID > node->ID)
	    node->right = insert_node(node->right, ID,left_stock, price);

	return node;

}
char aa[MAXLINE];
int a_num=0;
void printTree(item* Tree, int connfd){
        char buf[MAXLINE];
	if(Tree == NULL) return;
	printTree(Tree->left,connfd);
	if(a_num==0){
		sprintf(aa,"%d %d %d",Tree->ID, Tree->left_stock, Tree->price);
		a_num=1;
	}
	else{
		sprintf(aa,"%s %d %d %d",aa,Tree->ID, Tree->left_stock, Tree->price);
	}
//	printf("%s\n",buf);
//	fprintf(ff, "%d %d %d\n",Tree->ID, Tree->left_stock, Tree->price);
	printTree(Tree->right,connfd);
	
}
void printTofile(item* Tree, FILE *fp2){
    
   // 	printf("EEEEEEEEEEEEEEEEEEEE");
//	FILE *fp2 = fopen("stock.txt","a");
	if(Tree == NULL) return;
	printTofile(Tree->left,fp2);
	fprintf(fp2,"%d %d %d\n", Tree->ID, Tree->left_stock, Tree->price);
//	sprintf(string, "%s %d %d %d\n",string,Tree->ID, Tree->left_stock, Tree->price);
	printTofile(Tree->right,fp2);
//	fclose(fp2);

}
void init_pool(int listenfd, pool *p){

	int i;
	p->maxi = -1;
	for(i=0;i<FD_SETSIZE;i++){
		p->clientfd[i] = -1;
	}
	p->maxfd = listenfd;
	FD_ZERO(&p->read_set);
	FD_SET(listenfd, &p->read_set);
}

void add_client(int connfd, pool *p){
	int i;
	p->nready--;
	for (i=0;i<FD_SETSIZE;i++){
		if(p->clientfd[i]<0){
			p->clientfd[i] = connfd;
			Rio_readinitb(&p->clientrio[i],connfd);

			FD_SET(connfd, &p->read_set);

			if(connfd > p->maxfd)
			    p->maxfd = connfd;
			if(i > p->maxi)
			    p->maxi = i;
			break;
		

		}
	if(i==FD_SETSIZE)
	    app_error("add_client error: Too many clients");

	}
}
void check_clients(pool *p){
	int i, connfd, n;
	char buf[MAXLINE];
	char buffer[MAXLINE];
	rio_t rio;

	int show_flag = 0;
	int buy_flag = 0;
	int sell_flag = 0;
	int exit_flag = 0;
	int buy_ID = 0;
	int buy_num = 0;
	int sell_ID = 0;
	int sell_num = 0;
	char show[4] = "show";
	char buy[3] = "buy";
	char sell[4] = "sell";
	char exit[4] = "exit";
	for(i=0; (i<=p->maxi) && (p->nready >0); i++){
		connfd = p->clientfd[i];
		rio = p->clientrio[i];

		if((connfd > 0) && (FD_ISSET(connfd, &p->ready_set))){
			p->nready--;
			if((n=Rio_readlineb(&rio, buf, MAXLINE))!=0){

			    //	Rio_writen(connfd, buf,n);
				byte_cnt += n;
				show_flag = 0;
				buy_flag = 0;
				sell_flag = 0;

				for (int i = 0; i < 4; i++) {
					if (buf[i] == show[i])
						show_flag++;
					if (buf[i] == sell[i])
						sell_flag++;
					if (buf[i] == exit[i])
						exit_flag++;
				}

				for(int i=0;i<3;i++){
					if(buf[i] == buy[i])
					    buy_flag++;
				}
				if (show_flag == 4) {
					printTree(st_item,connfd);
					sprintf(buffer,"%s\n",aa);
					printf("aaaaaaa : %s",buf);
					a_num=0;
					//	printf("well");
					//	fread(buffer,1,MAXLINE,ff);
				//		printf("%s",buffer);

				}
				if (buy_flag == 3) {
					//	buy_ID = (int)buf[4] - 48;
					//	buy_num = (int)buf[6] - 48;
					sscanf(buf, "buy %d %d", &buy_ID, &buy_num);
				//	printf("%d %d\n", buy_ID, buy_num);
					item* temp = search(st_item, buy_ID);
					if (temp == NULL) {
						sprintf(buffer,"Not enough left stock\n");
					}
					else if (temp->left_stock >= buy_num) {

						temp->left_stock = temp->left_stock - buy_num;
						sprintf(buffer,"[buy] success\n");
				//		Rio_writen(connfd, buffer, strlen(buffer));
					}
					else {
						sprintf(buffer,"Not enough left stock\n");
					}

				}
				if (sell_flag == 4) {
					//	sell_ID = (int)buf[5] - 48;
					//	sell_num = (int)buf[7] - 48;
					sscanf(buf, "sell %d %d", &sell_ID, &sell_num);
					//	printf("[sell] success\n");
					item* temp2 = search(st_item, sell_ID);
					if (temp2 == NULL) {
						//	new_node(sell_ID, sell_num,1000);
						//printf("no data");
					}
					else {
						temp2->left_stock = temp2->left_stock + sell_num;
						sprintf(buffer,"[sell] success\n");
					//	Rio_writen(connfd, buffer,strlen(buffer));
					}
				}
				if (exit_flag == 4) {

					//  cli_num--;
					//  printf("\n\nclicli : %d\n");
					//  if(cli_num==0){
					 // 	printTofile(st_item);
					 // }
					break;
				}
			//	Rio_writen(connfd,buf,n);
				printf("buf : %s\n",buffer);
				Rio_writen(connfd, buffer , strlen(buffer));
				

			}
			else{
				cli_num--;
		///				printf("\n\nclicli : %d\n",cli_num);
				if (cli_num == 0) {
					end1 = clock();
					printf("time : %f\n", (float)(end1 - start1) / CLOCKS_PER_SEC);
					//		        printf("pppppppppprinnnnnnnnnnnnnnnnnt\n");
					//			string = "";
					//			printf("SSD");
					FILE *fp2 = fopen("stock.txt", "w");
					printTofile(st_item, fp2);
					fclose(fp2);
				}
				Close(connfd);
				FD_CLR(connfd, &p->read_set);
				p->clientfd[i] = -1;
			}
			

		}
	}
	
}
//item* st_item;

int main(int argc, char **argv) 
{
  //  st_item->num=0;
    //start1 = clock();
    int listenfd, connfd;
    static pool pool;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;  /* Enough space for any address */  //line:netp:echoserveri:sockaddrstorage
   // char client_hostname[MAXLINE], client_port[MAXLINE];

   // item *st_item = NULL;
    char line[MAXLINE];
    int a, b, c;
    if (argc != 2) {
	fprintf(stderr, "usage: %s <port>\n", argv[0]);
	exit(0);
    }
 //   item* st_item=NULL;
    listenfd = Open_listenfd(argv[1]);
    init_pool(listenfd, &pool);
  //  FD_ZERO(&read_set);
  //  FD_SET(STDIN_FILENO, &read_set);
   // FD_SET(listenfd, &read_set);
    
    FILE *fp = fopen("stock.txt","r");
 //   ff =fopen("temp.txt","w"); 

    while(!feof(fp)){
    	if(fgets(line,MAXLINE,fp)!= NULL);{
	sscanf(line,"%d %d %d",&a,&b,&c);
//	printf("%d %d %d\n",a,b,c);
	st_item = insert_node(st_item,a,b,c);
	}
    }
    fclose(fp);

    start1 = clock();
    while (1) {
		pool.ready_set = pool.read_set;
		pool.nready = Select(pool.maxfd+1, &pool.ready_set, NULL,NULL,NULL);
	
//	Select(listenfd+1, &ready_set, NULL, NULL, NULL);
///	if(FD_ISSET(STDIN_FILENO, &ready_set))
//	    command();
		if (FD_ISSET(listenfd, &pool.ready_set)) {
			clientlen = sizeof(struct sockaddr_storage);
			connfd = Accept(listenfd, (SA*)&clientaddr, &clientlen);
			cli_num++;
		//		printf("\naccept : %d\n",cli_num);
			add_client(connfd, &pool);
		}
		//printTree(st_item);
		//printTofile(st_item);
//		printf("done!");
		
	//	Close(connfd);

		check_clients(&pool);
    }
  //  printf("??");
    exit(0);
}

void command(void){
	char buf[MAXLINE];
	if(!Fgets(buf, MAXLINE, stdin))
	    exit(0);
//	printf("???%s", buf);
	
}


/* $end echoserverimain */
